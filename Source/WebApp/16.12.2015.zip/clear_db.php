<?php

include('db_config.php');
$verbindung = mysql_connect ($db_host,
$db_username, $db_password)or die ("keine Verbindung möglich. Benutzername oder Passwort sind falsch");
mysql_select_db($db_name)or die ("Die Datenbank existiert nicht.");



$fetchinfo_dev = mysql_query("DELETE FROM `node_schematic` WHERE 1");
$fetchinfo_dev = mysql_query("DELETE FROM `node_connections` WHERE 1");
echo "ok";
?>