
MyFigure = draw2d.shape.basic.Rectangle.extend({

    NAME : "MyFigure",
    
    /**
     * @constructor 
     * Creates a new figure element which is not assigned to any canvas.
     * 
     * @param {Object} [attr] the configuration of the shape
     */
    init : function(attr, idstr, params, tool_desc, type)
    {
    	this.tooltip = null;
    	
    	this.resizeable = false;
		this.tid = idstr;
		this.tool_desc = tool_desc;
		this.params = params;
		this.type = type;
		
		
		
    	this._super($.extend({width:50, height:50},attr));
        
        this.createPort("input", draw2d.layout.locator.LeftLocator);
        this.createPort("input", draw2d.layout.locator.LeftLocator);

        this.createPort("output",draw2d.layout.locator.RightLocator);
        
    },

    /**
     * @method
     * Change the color and the internal value of the figure.
     * Post the new value to related input ports.
     * 
     */
    onMouseEnter: function(){
        this.showTooltip();
    },
    
    onMouseLeave: function(){
        this.hideTooltip();
    },
    
    setPosition: function(x,y){
        this._super(x,y);
        this.positionTooltip();
    },
    
    hideTooltip:function(){          
        this.tooltip.remove();   
        this.tooltip = null;
    },
    
    
    showTooltip:function(){          
        this.tooltip= $("<div class='tooltip'>" + this.tool_desc + "</div>").appendTo('body');
        this.positionTooltip();        
    },
    
    positionTooltip: function(){
        if( this.tooltip===null){
            return;
        }
        
        var width =  this.tooltip.outerWidth(true);
        var tPosX = this.getAbsoluteX()+this.getWidth()/2-width/2+8;
        var tPosY = this.getAbsoluteY()+this.getHeight() + 20;
        this.tooltip.css({'top': tPosY, 'left': tPosX});
    }
    
});
