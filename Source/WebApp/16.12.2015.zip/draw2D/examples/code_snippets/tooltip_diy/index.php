﻿<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
<title></title>
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="viewport" content="width=device-width, minimum-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <link type="text/css" rel="stylesheet" href="./css/example.css" />
    <link type="text/css" rel="stylesheet" href="./css/tooltip.css" />
    <link type="text/css" rel="stylesheet" href="../../../css/contextmenu.css" />

    <SCRIPT src="../../../lib/shifty.js"></SCRIPT>
    <SCRIPT src="../../../lib/raphael.js"></SCRIPT>
    <SCRIPT src="../../../lib/jquery-1.10.2.min.js"></SCRIPT>
    <SCRIPT src="../../../lib/jquery.autoresize.js"></SCRIPT>
    <SCRIPT src="../../../lib/jquery-touch_punch.js"></SCRIPT>
    <SCRIPT src="../../../lib/jquery.contextmenu.js"></SCRIPT>
    <SCRIPT src="../../../lib/rgbcolor.js"></SCRIPT>
    <SCRIPT src="../../../lib/canvg.js"></SCRIPT>
    <SCRIPT src="../../../lib/Class.js"></SCRIPT>
    <SCRIPT src="../../../lib/json2.js"></SCRIPT>
    <SCRIPT src="../../../lib/pathfinding-browser.min.js"></SCRIPT>

    <SCRIPT src="../../../src/draw2d.js"></SCRIPT>
	    <SCRIPT src="../../../src/util/Polyfill.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/Base64.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/Debug.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/Color.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/ArrayList.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/SVGUtil.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/JSONUtil.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/UUID.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/spline/Spline.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/spline/CubicSpline.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/spline/CatmullRomSpline.js"> </SCRIPT>
    <SCRIPT src="../../../src/util/spline/BezierSpline.js"> </SCRIPT>
    <SCRIPT src="../../../src/geo/PositionConstants.js"> </SCRIPT>
    <SCRIPT src="../../../src/geo/Point.js"> </SCRIPT>
    <SCRIPT src="../../../src/geo/Rectangle.js"> </SCRIPT>
    <SCRIPT src="../../../src/geo/Util.js"> </SCRIPT>
    <SCRIPT src="../../../src/geo/Ray.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandType.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/Command.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandCollection.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandStack.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandStackEvent.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandStackEventListener.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandMove.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandMoveLine.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandMoveVertex.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandMoveVertices.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandResize.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandRotate.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandConnect.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandReconnect.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandDelete.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandDeleteGroup.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandAdd.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandGroup.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandUngroup.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandAddVertex.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandAssignFigure.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandBoundingBox.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandRemoveVertex.js"> </SCRIPT>
    <SCRIPT src="../../../src/command/CommandReplaceVertices.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/ConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/DirectRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/RubberbandRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/VertexRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/ManhattanConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/ManhattanBridgedConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/InteractiveManhattanConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/CircuitConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/SplineConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/FanConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/MazeConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/MuteableManhattanConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/connection/SketchConnectionRouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/mesh/MeshLayouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/mesh/ExplodeLayouter.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/mesh/ProposedMeshChange.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/Locator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/PortLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/XYAbsPortLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/XYRelPortLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/InputPortLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/OutputPortLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/ConnectionLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/ManhattanMidpointLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/PolylineMidpointLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/ParallelMidpointLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/TopLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/BottomLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/LeftLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/RightLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/locator/CenterLocator.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/EditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/CanvasPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/ConnectionInterceptorPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/KeyboardPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/DefaultKeyboardPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/ExtendedKeyboardPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/SelectionPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/SingleSelectionPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/GhostMoveSelectionPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/PanningSelectionPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/BoundingboxSelectionPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/ReadOnlySelectionPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/DecorationPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/FadeoutDecorationPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/CoronaDecorationPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/SnapToEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/SnapToGridEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/ShowGridEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/ShowDotEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/ShowChessboardEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/SnapToGeometryEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/SnapToInBetweenEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/canvas/SnapToCenterEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/FigureEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/DragDropEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/RegionEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/HorizontalEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/VerticalEditPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/SelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/ResizeSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/RectangleSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/BigRectangleSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/RoundRectangleSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/BusSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/WidthSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/VBusSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/HBusSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/AntSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/GlowSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/SlimSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/figure/VertexSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/line/LineSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/line/VertexSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/line/OrthogonalSelectionFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/port/PortFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/port/ElasticStrapFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/policy/port/IntrusivePortsFeedbackPolicy.js"> </SCRIPT>
    <SCRIPT src="../../../src/Configuration.js"> </SCRIPT>
    <SCRIPT src="../../../src/Canvas.js"> </SCRIPT>
    <SCRIPT src="../../../src/Selection.js"> </SCRIPT>
    <SCRIPT src="../../../src/Figure.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/Node.js"> </SCRIPT>
    <SCRIPT src="../../../src/VectorFigure.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Rectangle.js"> </SCRIPT>
    <SCRIPT src="../../../src/SetFigure.js"> </SCRIPT>
    <SCRIPT src="../../../src/SVGFigure.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/Hub.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/HorizontalBus.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/VerticalBus.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/Fulcrum.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Arc.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Oval.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Circle.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Label.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Text.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Line.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/PolyLine.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Image.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Polygon.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/Diamond.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/composite/Composite.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/composite/StrongComposite.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/composite/Group.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/composite/Jailhouse.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/composite/WeakComposite.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/composite/Raft.js"> </SCRIPT>
    <SCRIPT src="../../../src/Connection.js"> </SCRIPT>
    <SCRIPT src="../../../src/VectorFigure.js"> </SCRIPT>
    <SCRIPT src="../../../src/ResizeHandle.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/LineResizeHandle.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/LineStartResizeHandle.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/LineEndResizeHandle.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/VertexResizeHandle.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/basic/GhostVertexResizeHandle.js"> </SCRIPT>
    <SCRIPT src="../../../src/Port.js"> </SCRIPT>
    <SCRIPT src="../../../src/InputPort.js"> </SCRIPT>
    <SCRIPT src="../../../src/OutputPort.js"> </SCRIPT>
    <SCRIPT src="../../../src/HybridPort.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/anchor/ConnectionAnchor.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/anchor/ChopboxConnectionAnchor.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/anchor/FanConnectionAnchor.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/anchor/ShortesPathConnectionAnchor.js"> </SCRIPT>
    <SCRIPT src="../../../src/layout/anchor/CenterEdgeConnectionAnchor.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/arrow/CalligrapherArrowLeft.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/arrow/CalligrapherArrowDownLeft.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/Start.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/End.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/node/Between.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/note/PostIt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/flowchart/Document.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/widget/Widget.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/widget/Slider.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/diagram/Diagram.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/diagram/Pie.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/diagram/Sparkline.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/analog/OpAmp.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/analog/ResistorBridge.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/analog/ResistorVertical.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/analog/VoltageSupplyHorizontal.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/analog/VoltageSupplyVertical.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/layout/Layout.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/layout/HorizontalLayout.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/layout/VerticalLayout.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/layout/TableLayout.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/layout/FlexGridLayout.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Icon.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Thunder.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Snow.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Hail.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Rain.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Cloudy.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Sun.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Undo.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Detour.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Merge.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Split.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Fork.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ForkAlt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Exchange.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Shuffle.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Refresh.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ccw.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Acw.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Contract.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Expand.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Stop.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/End.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Start.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ff.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Rw.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ArrowRight.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ArrowLeft.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ArrowUp.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ArrowDown.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ArrowLeft2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ArrowRight2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Smile2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Smile.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Alarm.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Clock.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/StopWatch.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/History.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Future.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/GlobeAlt2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/GlobeAlt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Globe.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Warning.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Code.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Pensil.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Pen.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Plus.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Minus.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/TShirt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Sticker.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Page2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Page.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Landscape1.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Landscape2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Plugin.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Bookmark.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Hammer.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Users.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/User.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Customer.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Employee.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Anonymous.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Skull.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Mail.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Picture.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Bubble.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/CodeTalk.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Talkq.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Talke.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Home.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Lock.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Clip.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Star.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/StarOff.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Star2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Star2Off.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Star3.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Star3Off.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Chat.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Quote.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Gear2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Gear.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Wrench.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Wrench2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Wrench3.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ScrewDriver.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/HammerAndScrewDriver.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Magic.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Download.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/View.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Noview.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Cloud.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Cloud2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/CloudDown.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/CloudUp.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Location.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Volume0.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Volume1.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Volume2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Volume3.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Key.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ruler.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Power.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Unlock.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Flag.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Tag.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Search.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ZoomOut.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ZoomIn.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Cross.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Check.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Settings.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/SettingsAlt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Feed.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Bug.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Link.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Calendar.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Picker.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/No.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/CommandLine.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Photo.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Printer.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Export.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Import.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Run.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Magnet.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/NoMagnet.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ReflectH.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/ReflectV.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Resize2.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Rotate.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Connect.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Disconnect.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Folder.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Man.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Woman.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/People.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Parent.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Notebook.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Diagram.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/BarChart.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/PieChart.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/LineChart.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Apps.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Locked.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ppt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Lab.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Umbrella.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Dry.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ipad.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Iphone.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Jigsaw.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Lamp.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Lamp_alt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Video.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Palm.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Fave.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Help.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Crop.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/BioHazard.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/WheelChair.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Mic.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/MicMute.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/IMac.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Pc.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Cube.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/FullCube.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Font.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Trash.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/NewWindow.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/DockRight.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/DockLeft.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/DockBottom.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/DockTop.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Pallete.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Cart.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Glasses.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Package.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Book.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Books.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Icons.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/List.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Db.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Paper.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/TakeOff.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Landing.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Plane.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Phone.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/HangUp.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/SlideShare.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Twitter.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/TwitterBird.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Skype.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Windows.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Apple.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Linux.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/NodeJs.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/JQuery.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Sencha.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Vim.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/InkScape.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Aumade.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Firefox.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ie.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ie9.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Opera.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Chrome.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Safari.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/LinkedIn.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Flickr.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/GitHub.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/GitHubAlt.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Raphael.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/GRaphael.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Svg.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Usb.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/icon/Ethernet.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/pert/Activity.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/pert/Start.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/state/Start.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/state/End.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/state/State.js"> </SCRIPT>
    <SCRIPT src="../../../src/shape/state/Connection.js"> </SCRIPT>
    <SCRIPT src="../../../src/ui/LabelEditor.js"> </SCRIPT>
    <SCRIPT src="../../../src/ui/LabelInplaceEditor.js"> </SCRIPT>
    <SCRIPT src="../../../src/decoration/connection/Decorator.js"> </SCRIPT>
    <SCRIPT src="../../../src/decoration/connection/ArrowDecorator.js"> </SCRIPT>
    <SCRIPT src="../../../src/decoration/connection/DiamondDecorator.js"> </SCRIPT>
    <SCRIPT src="../../../src/decoration/connection/CircleDecorator.js"> </SCRIPT>
    <SCRIPT src="../../../src/decoration/connection/BarDecorator.js"> </SCRIPT>
    <SCRIPT src="../../../src/io/Reader.js"> </SCRIPT>
    <SCRIPT src="../../../src/io/Writer.js"> </SCRIPT>
    <SCRIPT src="../../../src/io/svg/Writer.js"> </SCRIPT>
    <SCRIPT src="../../../src/io/png/Writer.js"> </SCRIPT>
    <SCRIPT src="../../../src/io/json/Writer.js"> </SCRIPT>
    <SCRIPT src="../../../src/io/json/Reader.js"> </SCRIPT>
    <SCRIPT src="../../../src/storage/FileStorage.js"> </SCRIPT>
    <SCRIPT src="../../../src/storage/GoogleDrive.js"> </SCRIPT>
    <SCRIPT src="../../../src/storage/LocalFileStorage.js"> </SCRIPT>
    <SCRIPT src="../../../src/storage/TideSDKStorage.js"> </SCRIPT>
    

	<SCRIPT src="MyFigure.js"></SCRIPT>

<script type="text/javascript">
var id_count = 0;
 var canvas = null;
 
 var curr_zoom = 1;
 var zoom_inc = 0.5;
 var max_zoom = 10;
 var min_zoom = 0.2;
$(window).load(function () {

      canvas = new draw2d.Canvas("gfx_holder");
      curr_zoom = canvas.getZoom();
    
   
     
});


function add_bland(){
	  canvas.add(new MyFigure({x:100,y:100},id_count, "%", "tool_desc", "BLAND"));
	  id_count++;
};

function add_blor(){
	  canvas.add(new MyFigure({x:100,y:100},  id_count, "%", "tool_desc", "BLOR"));
	    id_count++;
};


function clear_all(){
	id_count = 0;
	canvas.clear();
}

function zoom_out(){
	if(curr_zoom <= (max_zoom - zoom_inc)){
		curr_zoom += zoom_inc;
		canvas.setZoom(curr_zoom, true);
	}
}

function zoom_in(){
	if(curr_zoom >= (min_zoom + zoom_inc)){
		curr_zoom -= zoom_inc;
		canvas.setZoom(curr_zoom, true);
	}
}

function center_view(){
	//array
}
</script>

</head>

<body>
<div id='toolbar'>
<input type="button" onclick="add_bland()" value="Add AND-GATE"/> 
<input type="button" onclick="add_blor()" value="Add OR-GATE"/> 

<input type="button" onclick="clear_all()" value="CLEAR"/> 
<input type="button" onclick="zoom_out()" value="ZOOM OUT"/> 
<input type="button" onclick="zoom_in()" value="ZOOM IN"/> 

<input type="button" onclick="center_view()" value="CENTER VIEW"/> 
</div> 
<div  onselectstart="javascript:/*IE8 hack*/return false" id="gfx_holder" style="width:1000px; height:1000px;">
</div>


</body>
</html>
