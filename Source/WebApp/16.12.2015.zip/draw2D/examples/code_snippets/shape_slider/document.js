
// the document to load.
var jsonDocument = 
    [
      {
          "type": "SliderShape",
          "id": "ebfb35bb-5767-8155-c804-14bd48789dc21",
          "x": 72,
          "y": 45
        }
      ,
      {
          "type": "draw2d.shape.analog.OpAmp",
          "id": "ebfb35bb-5767-8155-c804-14bd48789dc22",
          "x": 72,
          "y": 45
        }
     ];
