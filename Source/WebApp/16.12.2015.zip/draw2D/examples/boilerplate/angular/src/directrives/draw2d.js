"use strict";

var d2=angular.module('draw2d', []);
