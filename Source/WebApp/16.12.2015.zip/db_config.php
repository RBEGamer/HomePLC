<?php
$db_host="localhost"; // Host name 
$db_username="smartsps"; // Mysql username 
$db_password="smartsps"; // Mysql password 
$db_name="smartsps"; // Database name 
$log_mode_debug = 0;

?>