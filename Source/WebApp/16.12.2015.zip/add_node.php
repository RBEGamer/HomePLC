



<?php
/*

desc
param
nid
x
y
msi
*/

include('db_config.php');
$verbindung = mysql_connect ($db_host,
$db_username, $db_password)or die ("keine Verbindung möglich. Benutzername oder Passwort sind falsch");
mysql_select_db($db_name)or die ("Die Datenbank existiert nicht.");



$fetchinfo_dev = mysql_query("INSERT INTO `node_schematic`(`node_description`, `node_pos_x`, `node_pos_y`, `nid`, `params`) VALUES ('". $_POST['desc'] ."','". $_POST['x'] ."','". $_POST['y'] ."','". $_POST['nid'] ."','". $_POST['param'] ."')");

echo "ok";
?>